import java.util.Scanner;
class stdinfo
{
   Scanner in=new Scanner(System.in);
   String usn=new String();
   String name=new String();
   String branch=new String();
   int ph;
  public void read()
  {
   System.out.println("Enter USN,Name,Branch,Phone no.");
   usn=in.next();
   name=in.next();
   branch=in.next();
   ph=in.nextInt();
  }
  public void prt()
  {
   System.out.print(usn+"\t"+name+"\t"+branch+"\t"+ph+"\n");
  }
}
  class student
  {
   public static void main(String args[])
    {
       Scanner in=new Scanner(System.in);
       System.out.println("Enter the number of students");
       int n=in.nextInt();
       stdinfo[] ob=new stdinfo[n];
       System.out.println("Enter the details of the students");
       for(int i=0;i<n;i++)
      {    System.out.println("Student:"+(i+1));
           ob[i]=new stdinfo();
           ob[i].read();
      }
       System.out.println("Student List is:");
       System.out.print("USN\tName\tBranch\tPhone no\n");
       for(int i=0;i<n;i++)
        ob[i].prt();
     }
   }
