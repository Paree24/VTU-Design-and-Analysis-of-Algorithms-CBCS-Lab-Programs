import java.util.Random;
import java.util.Scanner;
class Quick
{
    static int a[]=new int[10000];
    static Random r=new Random();
    public static void main(String args[])
    {
     Scanner in=new Scanner(System.in);
     System.out.println("Enter the number of elements");
     int n=in.nextInt();
     for(int k=0;k<n;k++)
     {
      a[k]=5000+r.nextInt(999);
     }
     System.out.println("Before Quicksort");
     for(int m=0;m<n;m++)
     {
      System.out.print(a[m]+" ");
     }
     System.out.print("\n");
     System.out.println("After Quicksort");
     long startTime=System.nanoTime();
     Qsort(a,0,n-1);
     long stopTime=System.nanoTime();
     long eTime=stopTime-startTime;
     for(int h=0;h<n;h++)
     {
      System.out.print(a[h]+" ");
     }
     System.out.print("\n");
     System.out.println("Elapsed time ="+eTime);
   }
  public static int part(int a[],int low,int high)
  {
    int j=low;
    int pv=high;
    int i=j-1;
    int temp;
    while(j<=pv)
    {
     while(a[j]<a[pv])
      j++;
     while(a[j]>a[pv])
     {
       i++;
       temp=a[i];
       a[i]=a[j];
       a[j]=temp;
       j++;
     }
    if(a[j]==a[pv])
    { 
    i++;
    temp=a[i];
    a[i]=a[j];
    a[j]=temp;
    j++;
    }
  } 
    return i;
  }
  
  
  
  public static void Qsort(int a[],int low,int high)
  {
   if(low<=high)
   {
    int mid=part(a,low,high);
    Qsort(a,0,mid-1);
    Qsort(a,mid+1,high);
   }
  }
}
