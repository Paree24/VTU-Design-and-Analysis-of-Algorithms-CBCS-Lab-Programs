import java.util.*;
class merge
{
    static int a[]=new int[10000];
    static Random r=new Random();
    public static void main(String args[])
    {
     Scanner in=new Scanner(System.in);
     System.out.println("Enter the number of elements");
     int n=in.nextInt();
     for(int k=0;k<n;k++)
     {
      a[k]=r.nextInt(999);
     }
     System.out.println("Before Mergesort");
     for(int m=0;m<n;m++)
     {
      System.out.print(a[m]+" ");
     }
     System.out.print("\n");
     System.out.println("After Mergesort");
     long startTime=System.nanoTime();
     mergesort(a,0,n-1);
     long stopTime=System.nanoTime();
     long eTime=stopTime-startTime;
     for(int h=0;h<n;h++)
     {
      System.out.print(a[h]+" ");
     }
     System.out.print("\n");
     System.out.println("Elapsed time ="+(eTime/1000000));
   }
   public static void mergesort(int a[],int low,int high)
   {
     if(low<high)
     {
       int mid=(low+high)/2;
       mergesort(a,low,mid);
       mergesort(a,mid+1,high);
       merge(a,low,high,mid);
     }
   }
   public static void merge(int a[],int low,int high,int mid)
   {
    int i=low,j=mid+1,k=low;
    int b[]=new int[10000];
    while(i<=mid&&j<=high)
    {
      if(a[i]<a[j])
      {
        b[k]=a[i];
        k++;i++;
      }
      else
      {
        b[k]=a[j];
        k++;j++;
      }
    }
    while(i<=mid)
    {
      b[k]=a[i];
      k++;i++;
    }
    while(j<=high)
    {
      b[k]=a[j];
      k++;j++;
    }
    for(i=low;i<=high;i++)
    {
       a[i]=b[i];
    }
   }
  }

