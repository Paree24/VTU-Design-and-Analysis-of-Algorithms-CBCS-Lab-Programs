import java.util.*;
class Firstthread extends Thread
{
  Firstthread()
  {
    start();
  }
  public void run()
  {
   try
   {
     for(int i=0;i<3;i++)
     {
       Random r=new Random();    
       int n=r.nextInt(100);
       System.out.println("Number = "+n);
       new Secondthread(n);
       new Thirdthread(n);
       Thread.sleep(1000);
      }
    }
    catch(Exception e)
    {
      System.out.println("First thread interrupted");
    }
   System.out.println("First thread exiting");
  }
}
class Secondthread extends Thread
{
  int x;
  Secondthread(int n)
  {
    x=n;
    start();
  }
  public void run()
  {
   try
   {
     System.out.println(" Square = " +(x*x));
   }
    catch(Exception e)
    {
      System.out.println("Second thread interrupted");
    }
   System.out.println("Second thread exiting");
   }
}   
class Thirdthread extends Thread
{
  int x;
  Thirdthread(int n)
  {
    x=n;
    start();
  }
  public void run()
  {
   try
   {
     System.out.println("Cube = " +(x*x*x));
   }
    catch(Exception e)
    {
      System.out.println("Third thread interrupted");
    }
   System.out.println("Third thread exiting");
   }
}   
class Mainthread
{
  public static void main(String args[])
  {
    new Firstthread();
  }
}
