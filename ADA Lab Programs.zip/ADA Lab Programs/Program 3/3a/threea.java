import java.util.*;
class Exp
{
 public static void main(String par[])
 {
   Scanner in=new Scanner(System.in);
   System.out.println("Enter the value of a,b");
   int a=in.nextInt();
   int b=in.nextInt();
   try {
   int result=a/b;
   System.out.println("Result = "+result);
   }
   catch(Exception e) {
   System.out.println("Exception caught : "+e);
   }
 }
}
