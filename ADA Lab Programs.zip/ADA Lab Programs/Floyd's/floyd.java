import java.util.Scanner;
class Floyd
{
  public static void main(String args[])
  {
    Scanner in=new Scanner(System.in);
    int cost[][]=new int[10][10];
    System.out.println("Enter the number of nodes");
    int n=in.nextInt();
    System.out.println("Enter the cost matrix");
    for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
      cost[i][j]=in.nextInt();
    for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
      for(int k=0;k<n;k++)
       if(cost[j][k]>cost[j][i]+cost[i][k])
         cost[j][k]=cost[j][i]+cost[i][k];
    System.out.println("Matrix is ");
    for(int i=0;i<n;i++)
    {
     for(int j=0;j<n;j++)
       System.out.print(cost[i][j]+" ");
     System.out.println();
    }
   }
 }
