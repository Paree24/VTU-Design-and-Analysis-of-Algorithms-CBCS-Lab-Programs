import java.util.*;
class Customer
{
 public static void main(String par[])
 {
  String name=new String();
  Scanner in=new Scanner(System.in);
  System.out.println("Enter name and DOB of customer in format <name,dd/mm/yyyy");
  name=in.nextLine();
  StringTokenizer S= new StringTokenizer(name,"/");
  int n=S.countTokens();
  for(int i=1;i<=n&&S.hasMoreTokens();i++)
  {
   System.out.print(S.nextToken());
   if(i<n)
   System.out.print(",");
  }
  System.out.println();
 }
}
